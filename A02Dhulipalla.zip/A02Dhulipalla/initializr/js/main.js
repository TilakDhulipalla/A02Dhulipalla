
function getFName()
{ 
   var first=document.getElementByID("first").value;
   
    if(FName.value!="")
    {
        Fname = parseInt(FName.value);
    }
return Fname;

}
function getLName()
{  
        var last=document.getElementByID("last").value;
   
    if(LName.value!="")
    {
        Lname = parseInt(LName.value);
    }
return Lname;
}


function getdays()
{
    
  
    var days = document.getElementById("noofdays");
    
    
    if(noofdays.value!="")
    {
        days = parseInt(noofdays.value);
    }
    else{
        alert("enter number of days " );
    }
return days;
}

function selectcar(){
    var car=document.getElementByID("choose").value;
    var price;

    if(car=="mustang")
       price = 200;
      else if(car=="charger")
      price=150;
      else if(car=="civic")
      price=100;
      else if(car=="camaro")
      price= 180;
   return price;

}

function result(){

    
    totalcost= selectcar()*getdays();
    return totalcost;
    alert(totalcost);
    var finalcost=getElementByID("final").innerHTML();
    finalcost=totalcost;
    window.alert(finalcost);
}